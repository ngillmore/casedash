#!/bin/bash
# Helper script for Conky to safely query APC UPS telemetry without escaping hell

case "${1:-}" in
    status)
        apcaccess status | grep -E "^STATUS" | awk '{print $3}'
        ;;
    linev)
        apcaccess status | grep -E "^LINEV" | awk '{print $3, $4}'
        ;;
    bcharge)
        apcaccess status | grep -E "^BCHARGE" | awk '{print $3, $4}'
        ;;
    battv)
        apcaccess status | grep -E "^BATTV" | awk '{print $3, $4}'
        ;;
    timeleft)
        apcaccess status | grep -E "^TIMELEFT" | awk '{print $3, $4}'
        ;;
    power)
        LOAD=$(apcaccess status | grep -E "^LOADPCT" | awk '{print $3}')
        NOM=$(apcaccess status | grep -E "^NOMPOWER" | awk '{print $3}')
        if [ -n "$LOAD" ] && [ -n "$NOM" ]; then
            echo "$(( ${LOAD%.*} * ${NOM%.*} / 100 )) Watts (${LOAD}% of ${NOM}W max)"
        else
            echo "N/A"
        fi
        ;;
    *)
        echo "Usage: $0 {status|linev|bcharge|battv|timeleft|power}"
        exit 1
        ;;
esac
