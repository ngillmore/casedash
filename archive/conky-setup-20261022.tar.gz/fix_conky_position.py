#!/usr/bin/env python3
"""Place the Conky override-redirect window on the HYTE case screen.

The problem
-----------
Conky is launched with `-m 1` (xinerama head 1 = the case screen at x=3440) and
conky.conf sets `gap_x = 3440`. Conky applies BOTH, so the window is created at
x ~= 6880 (observed raw geom.x=6876) -- off the right edge of the 4540px virtual
desktop. The window is mapped and live but never visible.

What "correct" looks like
-------------------------
`xrandr --listmonitors` (XWayland) reports the case screen at +3440+0, and the
displayed position of a window is its ROOT position from `translate_coords`.
So the target is root x = 3440.

Coordinate transform
--------------------
On this XWayland root the compositor applies a negation transform: for every
window `translate_coords(root,0,0)` returns the negative of its raw geometry, so
a window that should display at root x=3440 carries raw geom.x = -3440. A
`configure(x=X)` write consequently lands the window at displayed root -X.

=> To display at root TARGET_X we must configure x = -TARGET_X.

Verification therefore reads the ROOT position (translate_coords), never the raw
geom, because geom is the mirrored space here.
"""
import sys
import time
import Xlib
from Xlib import X, display

# Case screen: displayed (= root) coordinates.
TARGET_X, TARGET_Y = 3440, 0
TARGET_W, TARGET_H = 1100, 3840


def find_conky_window(d):
    """Search the X window tree for a window with WM_CLASS containing 'conky'."""
    root = d.screen().root

    def search(window):
        try:
            cls = window.get_wm_class()
            if cls and 'conky' in cls:
                return window
        except Exception:
            pass
        try:
            children = window.query_tree().children
            for child in children:
                result = search(child)
                if result:
                    return result
        except Exception:
            pass
        return None

    return search(root)


def root_xy(win, root):
    """Window's DISPLAYED position (root coordinates). The source of truth."""
    t = win.translate_coords(root, 0, 0)
    return t.x, t.y


def main():
    d = display.Display(':0')
    root = d.screen().root

    conky_win = None
    for _ in range(20):
        conky_win = find_conky_window(d)
        if conky_win:
            break
        time.sleep(0.5)

    if not conky_win:
        print("ERROR: Conky window not found", file=sys.stderr)
        sys.exit(1)

    geom = conky_win.get_geometry()
    rx, ry = root_xy(conky_win, root)

    if rx == TARGET_X and ry == TARGET_Y:
        print(f"Conky already at correct position: root={rx},{ry} "
              f"{geom.width}x{geom.height}")
        d.close()
        return

    print(f"Conky at wrong position: root={rx},{ry} "
          f"geom={geom.x},{geom.y} {geom.width}x{geom.height}")
    print(f"Moving to: root={TARGET_X},{TARGET_Y} {TARGET_W}x{TARGET_H}")

    # Negation transform: configuring x=-TARGET_X displays at root TARGET_X.
    cfg_x, cfg_y = -TARGET_X, -TARGET_Y

    for attempt in range(2):
        conky_win.configure(x=cfg_x, y=cfg_y, width=TARGET_W, height=TARGET_H)
        d.flush()
        time.sleep(0.5)
        geom = conky_win.get_geometry()
        rx, ry = root_xy(conky_win, root)
        label = "New position" if attempt == 0 else "Final position"
        print(f"{label}: root={rx},{ry} {geom.width}x{geom.height}")
        if rx == TARGET_X and ry == TARGET_Y:
            break
        if attempt == 0:
            print("WARNING: Geometry didn't stick, trying again...",
                  file=sys.stderr)
    else:
        print("ERROR: could not place window at target", file=sys.stderr)
        d.close()
        sys.exit(1)

    conky_win.configure(stack_mode=X.Above)
    d.flush()
    d.close()


if __name__ == '__main__':
    main()