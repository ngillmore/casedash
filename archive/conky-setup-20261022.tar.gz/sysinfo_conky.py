#!/usr/bin/env python3
"""Conky system info from fastfetch — single-process, atomic cache.

Called by Conky's execi with a field name argument. Caches fastfetch JSON
to a file with file locking so concurrent calls from Conky don't race.

Usage: sysinfo_conky.py <field>
Fields: os host packages shell dewm display disk swap localip
"""
import sys
import os
import json
import time
import fcntl
import subprocess

CACHE_FILE = "/tmp/conky_fastfetch_cache.json"
CACHE_TTL = 50  # seconds
INDENT = " " * 11  # align continuation lines under the value column


def _multiline(lines):
    """Join lines with spaces for continuation indentation."""
    if not lines:
        return "N/A"
    return lines[0] + "".join(f"\n{INDENT}{l}" for l in lines[1:])


def _extract(items, type_name, formatter):
    for item in items:
        if item.get("type") == type_name:
            return formatter(item.get("result", {}))
    return "N/A"


def _packages(items):
    for item in items:
        if item.get("type") == "Packages":
            r = item.get("result", {})
            parts = []
            if r.get("pacman"):
                parts.append(f"{r['pacman']} (pacman)")
            if r.get("flatpakSystem"):
                parts.append(f"{r['flatpakSystem']} (flatpak)")
            return ", ".join(parts) if parts else "N/A"
    return "N/A"


def _shell(items):
    # fastfetch reports the calling process, not the user's login shell.
    # Read it directly from /etc/passwd + query the version.
    import pwd
    pw = pwd.getpwuid(os.getuid())
    shell_path = pw.pw_shell  # e.g. /bin/fish
    shell_name = os.path.basename(shell_path)  # e.g. fish
    # Get version
    try:
        r = subprocess.run([shell_path, "--version"], capture_output=True, text=True, timeout=3)
        ver = r.stdout.strip().split(", version")[-1].strip() if ", version" in r.stdout else ""
        # fish outputs: "fish, version 4.8.1"
        if not ver:
            # bash outputs: "GNU bash, version 5.3.15(1)-release ..."
            ver = r.stdout.strip().split("version ")[-1].split("(")[0].strip() if "version " in r.stdout else ""
        if ver:
            return f"{shell_name} {ver}"
    except Exception:
        pass
    return shell_name or "N/A"


def _dewm(items):
    de = wm = ""
    for item in items:
        if item.get("type") == "DE":
            de = item.get("result", {}).get("prettyName", "")
        elif item.get("type") == "WM":
            wm = item.get("result", {}).get("prettyName", "")
    return f"{de} / {wm}" if de and wm else de or wm or "N/A"


def _display(items):
    for item in items:
        if item.get("type") == "Display":
            results = item.get("result", [])
            if isinstance(results, list):
                lines = []
                for d in results:
                    name = d.get("name", "")
                    o = d.get("output", {})
                    w, h = o.get("width", 0), o.get("height", 0)
                    hz = o.get("refreshRate", 0)
                    prim = " (primary)" if d.get("primary", False) else ""
                    if w and h:
                        s = f"{name}: {w}x{h}"
                        if hz:
                            s += f" @ {hz:.0f}Hz"
                        s += prim
                        lines.append(s)
                # First line inline, rest indented to align under the value
                return _multiline(lines)
    return "N/A"


def _disk(items):
    for item in items:
        if item.get("type") == "Disk":
            results = item.get("result", [])
            if isinstance(results, list):
                lines = []
                for d in results:
                    if "Subvolume" in d.get("volumeType", []):
                        continue
                    mp = d.get("mountpoint", "")
                    b = d.get("bytes", {})
                    total = b.get("total", 0)
                    used = b.get("used", 0)
                    if total > 0:
                        pct = used * 100 / total
                        lines.append(f"{mp} {used/1073741824:.0f}G/{total/1073741824:.0f}G ({pct:.0f}%)")
                return _multiline(lines)
    return "N/A"


def _swap(items):
    for item in items:
        if item.get("type") == "Swap":
            results = item.get("result", [])
            if isinstance(results, list):
                for d in results:
                    used = d.get("used", 0)
                    total = d.get("total", 0)
                    if total > 0:
                        if used < 1073741824:  # under 1 GiB, show in MiB
                            return f"{used/1048576:.1f} MiB / {total/1073741824:.2f} GiB ({used*100/total:.0f}%)"
                        return f"{used/1073741824:.2f} GiB / {total/1073741824:.2f} GiB ({used*100/total:.0f}%)"
                    return "N/A"
    return "N/A"


def _localip(items):
    for item in items:
        if item.get("type") == "LocalIp":
            results = item.get("result", [])
            if isinstance(results, list):
                for d in results:
                    ipv4 = d.get("ipv4", "")
                    if ipv4:
                        return f"{d.get('name','')}: {ipv4}"
    return "N/A"


FIELDS = {
    "os": lambda items: _extract(items, "OS", lambda r: r.get("prettyName", "N/A")),
    "host": lambda items: _extract(items, "Host", lambda r: f'{r.get("vendor","")} {r.get("name","")}'.strip() or "N/A"),
    "packages": _packages,
    "shell": _shell,
    "dewm": _dewm,
    "display": _display,
    "disk": _disk,
    "swap": _swap,
    "localip": _localip,
}


def get_cached_json():
    """Get fastfetch JSON with atomic file locking."""
    now = time.time()
    need_refresh = True

    if os.path.exists(CACHE_FILE):
        mtime = os.path.getmtime(CACHE_FILE)
        if now - mtime < CACHE_TTL:
            need_refresh = False

    if need_refresh:
        # Use a lock file so only one process refreshes; others wait for it
        lock_file = CACHE_FILE + ".lock"
        with open(lock_file, "w") as lf:
            try:
                fcntl.flock(lf, fcntl.LOCK_EX)  # blocking — wait for whoever is refreshing
                # Got the lock — check again in case another process just refreshed
                if os.path.exists(CACHE_FILE):
                    mtime = os.path.getmtime(CACHE_FILE)
                    if time.time() - mtime < CACHE_TTL:
                        need_refresh = False
                if need_refresh:
                    result = subprocess.run(
                        ["fastfetch", "--logo", "none", "--format", "json"],
                        capture_output=True, text=True, timeout=10
                    )
                    if result.returncode == 0 and result.stdout.strip():
                        # Write atomically: write to temp then rename
                        tmp = CACHE_FILE + ".tmp"
                        with open(tmp, "w") as f:
                            f.write(result.stdout)
                        os.rename(tmp, CACHE_FILE)
            finally:
                try:
                    fcntl.flock(lf, fcntl.LOCK_UN)
                except Exception:
                    pass

    # Read the cache (may be slightly stale but always valid JSON)
    try:
        with open(CACHE_FILE, "r") as f:
            return json.loads(f.read())
    except (json.JSONDecodeError, FileNotFoundError, IOError):
        return []


def main():
    field = sys.argv[1] if len(sys.argv) > 1 else ""
    if field not in FIELDS:
        print("N/A")
        return

    items = get_cached_json()
    print(FIELDS[field](items))


if __name__ == "__main__":
    main()