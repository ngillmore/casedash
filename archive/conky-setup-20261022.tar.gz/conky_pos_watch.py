#!/usr/bin/env python3
"""Keep the Conky override-redirect window anchored to the HYTE case screen.

Why this exists
---------------
Conky creates its override-redirect window at the wrong XWayland position.
`fix_conky_position.py` moves it correctly, but Conky *re-creates* that window
every time its config is reloaded (SIGHUP, or the automatic reload it performs
when conky.conf changes on disk). Each reload drops the window back to the bad
position, which is why editing conky.conf silently broke the layout.

This daemon watches for config modifications and re-applies the geometry.
It is event-driven: it blocks on inotify and does no work at all until a write
lands in the config directory, so an untouched Conky costs nothing beyond an
idle file descriptor. Two signals are combined, because either alone is
unreliable:

  1. inotify (IN_CLOSE_WRITE | IN_MOVED_TO) on ~/.config/conky/ -- the trigger.
     Both mask bits matter: in-place writes fire IN_CLOSE_WRITE, while
     write-then-rename editors (vim, many IDEs) fire IN_MOVED_TO.
  2. journald, polled on its own slow timer -- conky's own "modified, reloading"
     line is the authoritative signal, and it also catches the SIGHUP/restart
     path that inotify cannot see.

     IMPORTANT: this poll must NOT be gated on an inotify trigger being pending.
     Conky processes a config change ASYNCHRONOUSLY: it logs "modified,
     reloading" and re-creates its window a moment AFTER the file write. The
     inotify debounce (DEBOUNCE_S) therefore expires and runs the fixer on the
     OLD window before the reload has happened -- the fixer reports "already
     correct", the trigger clears, and the real reload then drops the window
     off-screen with nothing left to notice it. Polling journald independently
     is what makes the reload reliably caught.

If inotify is unavailable the daemon degrades to a 1s journal poll, since it
would otherwise have no trigger at all.

Both paths funnel into one debounced re-fix; the "already correct" early-exit
in fix_conky_position.py makes redundant calls free.

Deliberately dependency-free: only ctypes/libc inotify + python-xlib, both of
which are already present. No pip installs, no file churn.
"""
import ctypes
import ctypes.util
import os
import select
import struct
import subprocess
import sys
import time

CONKY_DIR = os.path.expanduser("~/.config/conky")
WATCH_FILES = ("conky.conf",)
FIX_SCRIPT = os.path.join(CONKY_DIR, "fix_conky_position.py")

# How long to wait after a trigger before acting. Editors write files in several
# syscalls; a short debounce avoids running the fixer mid-write. Also coalesces
# an inotify trigger and a journal trigger describing the same reload.
DEBOUNCE_S = 1.5

# Journald poll interval. This is a SAFETY NET for reload paths inotify cannot
# see (e.g. `systemctl --user restart conky.service`, which re-creates the window
# with no config write). It is deliberately slow: each poll spawns a journalctl
# process, and a 1s interval meant a journalctl fork every second forever, which
# is exactly the kind of idle background load to avoid on a gaming box. The
# inotify path is near-instant for ordinary config edits, so this latency only
# applies to the restart case.
JOURNAL_POLL_S = 10.0

# If we trigger but Conky's window is briefly absent (mid-reload), retry.
# The watcher no longer orders After=conky.service (that caused an ordering
# cycle at boot), so it can legitimately start before Conky has forked and
# mapped its window. The initial run_fix() therefore has to wait out Conky's
# whole startup, not just a reload gap: 6 * 0.5s = 3s was too short and made the
# first placement a silent no-op. 40 * 0.5s = 20s covers a cold start.
FIX_RETRIES = 40
FIX_RETRY_DELAY_S = 0.5

# inotify constants
IN_CLOSE_WRITE = 0x00000008
IN_MOVED_TO = 0x00000080
IN_CREATE = 0x00000100
IN_MASK = IN_CLOSE_WRITE | IN_MOVED_TO | IN_CREATE
IN_NONBLOCK = 0o4000

EVENT_STRUCT = "iIII"
EVENT_SIZE = struct.calcsize(EVENT_STRUCT)


def log(msg):
    """Unbuffered stdout so journald captures it live."""
    print(f"[{time.strftime('%H:%M:%S')}] {msg}", flush=True)


class Inotify:
    """Minimal libc inotify wrapper via ctypes."""

    def __init__(self):
        libc_name = ctypes.util.find_library("c") or "libc.so.6"
        self.libc = ctypes.CDLL(libc_name, use_errno=True)
        self.fd = self.libc.inotify_init1(IN_NONBLOCK)
        if self.fd < 0:
            err = ctypes.get_errno()
            raise OSError(err, f"inotify_init1 failed: {os.strerror(err)}")
        self.wd_to_path = {}

    def add_watch(self, path):
        wd = self.libc.inotify_add_watch(
            self.fd, path.encode("utf-8"), IN_MASK
        )
        if wd < 0:
            err = ctypes.get_errno()
            raise OSError(
                err, f"inotify_add_watch({path}) failed: {os.strerror(err)}"
            )
        self.wd_to_path[wd] = path
        return wd

    def read_events(self):
        """Return a set of filenames that changed (may be empty)."""
        changed = set()
        try:
            buf = os.read(self.fd, 4096 * 8)
        except BlockingIOError:
            return changed
        except OSError:
            return changed
        offset = 0
        while offset + EVENT_SIZE <= len(buf):
            wd, mask, cookie, length = struct.unpack(
                EVENT_STRUCT, buf[offset : offset + EVENT_SIZE]
            )
            offset += EVENT_SIZE
            name = buf[offset : offset + length].split(b"\x00")[0].decode(
                "utf-8", "replace"
            )
            offset += length
            if name:
                changed.add(name)
            elif wd in self.wd_to_path:
                changed.add(os.path.basename(self.wd_to_path[wd]))
        return changed


def run_fix():
    """Invoke the position fixer, retrying if Conky's window is mid-recreate."""
    env = dict(os.environ)
    env["DISPLAY"] = ":0"
    env["XDG_RUNTIME_DIR"] = "/run/user/1000"
    if "XAUTHORITY" not in env:
        import glob

        candidates = sorted(glob.glob("/run/user/1000/xauth_*"))
        if candidates:
            env["XAUTHORITY"] = candidates[0]

    for attempt in range(FIX_RETRIES):
        try:
            proc = subprocess.run(
                [sys.executable, FIX_SCRIPT],
                capture_output=True,
                text=True,
                timeout=20,
                env=env,
            )
        except subprocess.TimeoutExpired:
            log("fix timed out; retrying")
            time.sleep(FIX_RETRY_DELAY_S)
            continue

        out = (proc.stdout or "").strip()
        err = (proc.stderr or "").strip()

        if proc.returncode == 0:
            if "already at correct position" in out:
                log("position already correct")
            else:
                log(out.replace("\n", " | ") or "position corrected")
            return True

        # "window not found" is expected mid-reload -- back off and retry.
        if "not found" in err or "not found" in out:
            time.sleep(FIX_RETRY_DELAY_S)
            continue

        log(f"fix failed rc={proc.returncode}: {err or out}")
        return False

    log("gave up: conky window never appeared")
    return False


def journal_cursor():
    """Return a cursor at the current end of the conky journal, or None."""
    try:
        proc = subprocess.run(
            [
                "journalctl",
                "--user",
                "-u",
                "conky.service",
                "-n",
                "0",
                "--show-cursor",
                "--no-pager",
            ],
            capture_output=True,
            text=True,
            timeout=10,
        )
    except (subprocess.TimeoutExpired, FileNotFoundError):
        return None
    for line in (proc.stdout or "").splitlines():
        if "-- cursor:" in line:
            return line.split("-- cursor:", 1)[1].strip()
    return None


def journal_since(cursor):
    """Return new journal lines since cursor, plus the new cursor."""
    cmd = ["journalctl", "--user", "-u", "conky.service", "--no-pager", "-o", "cat"]
    if cursor:
        cmd += ["--after-cursor", cursor, "--show-cursor"]
    else:
        cmd += ["-n", "0", "--show-cursor"]
    try:
        proc = subprocess.run(cmd, capture_output=True, text=True, timeout=10)
    except (subprocess.TimeoutExpired, FileNotFoundError):
        return [], cursor
    out = proc.stdout or ""
    new_cursor = cursor
    lines = []
    for line in out.splitlines():
        if "-- cursor:" in line:
            new_cursor = line.split("-- cursor:", 1)[1].strip()
        else:
            lines.append(line)
    return lines, new_cursor


def main():
    log("starting conky position watcher")

    try:
        ino = Inotify()
    except OSError as e:
        log(f"inotify unavailable ({e}); falling back to journal polling only")
        ino = None

    if ino:
        try:
            ino.add_watch(CONKY_DIR)
            # Also watch the files directly so a rename-replace still matches.
            for f in WATCH_FILES:
                p = os.path.join(CONKY_DIR, f)
                if os.path.exists(p):
                    ino.add_watch(p)
            log(f"watching {CONKY_DIR} for config writes")
        except OSError as e:
            log(f"could not add inotify watch ({e}); journal polling only")
            ino = None

    # Make sure we start from a known-good layout.
    run_fix()

    cursor = journal_cursor()

    if ino:
        log("idle -- blocked on inotify, no polling")
    else:
        # inotify is the only trigger we have; without it we must poll or we'd
        # never notice a reload at all.
        log(f"no inotify; falling back to journal polling every {JOURNAL_POLL_S}s")

    pending_trigger = None
    last_journal_poll = 0.0

    while True:
        # Block on inotify until a trigger fires OR the journal poll is due.
        # The timeout must account for BOTH the pending-trigger debounce and the
        # independent journal poll, otherwise a long idle block would starve the
        # journal check and a reload would go unnoticed.
        if ino:
            deadlines = [max(0.0, JOURNAL_POLL_S - (time.monotonic() - last_journal_poll))]
            if pending_trigger is not None:
                deadlines.append(max(0.0, DEBOUNCE_S - (time.monotonic() - pending_trigger)))
            wait = min(deadlines)
            readable, _, _ = select.select([ino.fd], [], [], wait)
            if readable:
                changed = ino.read_events()
                relevant = {
                    c for c in changed if c.endswith((".conf", ".lua")) or c in WATCH_FILES
                }
                if relevant:
                    log(f"inotify: {', '.join(sorted(relevant))} written")
                    pending_trigger = time.monotonic()
        else:
            time.sleep(JOURNAL_POLL_S)

        now = time.monotonic()

        # Journal poll runs on its own timer, NOT gated on a pending trigger.
        # Conky logs its reload asynchronously, after any inotify debounce has
        # already expired, so gating this on pending_trigger misses the reload.
        if now - last_journal_poll >= JOURNAL_POLL_S:
            last_journal_poll = now
            lines, cursor = journal_since(cursor)
            for line in lines:
                if "modified, reloading" in line:
                    log("journal: conky reloaded config")
                    pending_trigger = now
                    break

        # Fire once the debounce window has elapsed with no newer trigger.
        if pending_trigger is not None and (now - pending_trigger) >= DEBOUNCE_S:
            pending_trigger = None
            # Let conky finish re-creating the window before we move it.
            time.sleep(0.5)
            run_fix()


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        sys.exit(0)
